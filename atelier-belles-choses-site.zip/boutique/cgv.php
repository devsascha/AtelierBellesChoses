<?php
require __DIR__ . '/inc/layout.php';
site_head('Conditions générales de vente');
$shop = e(setting('shop_name'));
?>
<h1>Conditions générales de vente</h1>
<p class="small">Vendeur : <?= $shop ?>, <?= e(setting('owner_name') ?: 'à compléter') ?>, SIRET <?= e(setting('siret') ?: 'à compléter') ?>, <?= e(setting('address') ?: 'adresse à compléter') ?>. TVA non applicable, art. 293 B du CGI.</p>

<h2>1. Produits</h2>
<p>Les créations sont réalisées à la main : de légères différences de teinte, de motif ou de finition par rapport aux photos sont normales et font le charme de l'artisanat. Les photos sont non contractuelles.</p>

<h2>2. Prix</h2>
<p>Les prix sont indiqués en euros, toutes taxes comprises (TVA non applicable). Les frais de livraison sont affichés avant le paiement.</p>

<h2>3. Commande et paiement</h2>
<p>La commande est validée après paiement par carte bancaire via la plateforme sécurisée Stripe. Un e-mail de confirmation est envoyé. Le vendeur peut annuler et rembourser une commande en cas d'indisponibilité exceptionnelle d'un article.</p>

<h2>4. Livraison</h2>
<p><?= e(setting('delay_text')) ?> Les créations sur commande ou sur mesure demandent un délai de fabrication précisé lors de la commande ou du devis. Un retrait en main propre peut être proposé lorsque cette option est affichée au moment de la commande.</p>

<h2>5. Droit de rétractation</h2>
<p>Pour les articles standards, vous disposez de 14 jours à compter de la réception pour vous rétracter, sans avoir à justifier de motif, en écrivant à <?= e(setting('email_contact')) ?>. Les articles doivent être renvoyés neufs, non portés, non lavés, dans leur emballage d'origine. Les frais de retour sont à votre charge. Le remboursement intervient sous 14 jours après réception du retour.</p>
<p>Conformément à l'article L221-28 du Code de la consommation, le droit de rétractation ne s'applique pas aux biens confectionnés selon vos spécifications ou nettement personnalisés (commandes sur mesure).</p>

<h2>6. Garanties légales</h2>
<p>Les produits bénéficient de la garantie légale de conformité (articles L217-3 et suivants du Code de la consommation) et de la garantie des vices cachés (articles 1641 et suivants du Code civil).</p>

<h2>7. Entretien</h2>
<p>Pour que les créations durent, respectez les conseils d'entretien communiqués avec chaque article.</p>

<h2>8. Médiation et litiges</h2>
<p>En cas de litige, contactez-nous d'abord : <?= e(setting('email_contact')) ?>. À défaut d'accord, vous pouvez recourir gratuitement au médiateur de la consommation : <?= e(setting('mediator')) ?>. Le droit français est applicable.</p>

<h2>9. Données personnelles</h2>
<p>Voir notre <a href="<?= url('confidentialite.php') ?>">politique de confidentialité</a>.</p>
<?php site_foot();
