<?php
require __DIR__ . '/_layout.php';
$todo = (int)row("SELECT COUNT(*) c FROM orders WHERE status IN ('payée','en préparation')")['c'];
$rev = (int)row("SELECT COUNT(*) c FROM reviews WHERE status = 'en attente'")['c'];
$req = (int)row("SELECT COUNT(*) c FROM requests WHERE status = 'nouvelle'")['c'];
$low = rows('SELECT id, name, stock FROM products WHERE active = 1 AND made_to_order = 0 AND stock <= 1 ORDER BY stock, name LIMIT 10');
admin_head('Accueil', 'index.php');
$defaultPwd = password_verify((string)cfg('admin_password', 'ChangezMoi!2026'), setting('admin_hash'));
?>
<h1>Bonjour 👋</h1>
<?php if ($defaultPwd): ?><div class="flash err">Pensez à changer le mot de passe dans <a href="reglages.php">Réglages</a>.</div><?php endif; ?>
<?php if (cfg('stripe_secret') === ''): ?><div class="flash err">Le paiement en ligne n'est pas encore activé (clé Stripe manquante dans config.php).</div><?php endif; ?>
<div class="tiles">
  <a class="tile <?= $todo ? 'alert' : '' ?>" href="commandes.php"><b><?= $todo ?></b>commande(s) à préparer</a>
  <a class="tile <?= $req ? 'alert' : '' ?>" href="demandes.php"><b><?= $req ?></b>demande(s) sur mesure</a>
  <a class="tile <?= $rev ? 'alert' : '' ?>" href="avis.php"><b><?= $rev ?></b>avis à valider</a>
</div>
<p class="actions"><a class="btn" href="produit.php">+ Ajouter un produit</a> <a class="btn ghost" href="produits.php">Gérer mes produits</a></p>
<?php if ($low): ?>
<h2>Stock bas</h2>
<div class="panel"><?php foreach ($low as $p): ?><div><a href="produit.php?id=<?= (int)$p['id'] ?>"><?= e($p['name']) ?></a> : <?= (int)$p['stock'] === 0 ? '<span class="tag bad">épuisé</span>' : 'reste 1' ?></div><?php endforeach; ?></div>
<?php endif; ?>
<?php admin_foot();
