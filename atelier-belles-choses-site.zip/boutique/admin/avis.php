<?php
require __DIR__ . '/_layout.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $id = (int)post('id');
    $a = post('action');
    if ($a === 'ok') {
        run("UPDATE reviews SET status = 'validé' WHERE id = ?", [$id]);
        flash('Avis publié.');
    } elseif ($a === 'hide') {
        run("UPDATE reviews SET status = 'en attente' WHERE id = ?", [$id]);
        flash('Avis dépublié.');
    } elseif ($a === 'delete') {
        run('DELETE FROM reviews WHERE id = ?', [$id]);
        flash('Avis supprimé.');
    } elseif ($a === 'add') {
        $author = post('author');
        $text = post('text');
        if ($author !== '' && $text !== '') {
            run("INSERT INTO reviews (product_id, author, rating, text, status) VALUES (NULL, ?, ?, ?, 'validé')", [mb_substr($author, 0, 60), max(1, min(5, (int)post('rating', '5'))), mb_substr($text, 0, 1500)]);
            flash('Avis ajouté et publié.');
        }
    }
    redirect('avis.php');
}
$list = rows('SELECT r.*, p.name AS pname FROM reviews r LEFT JOIN products p ON p.id = r.product_id ORDER BY (r.status = \'en attente\') DESC, r.id DESC LIMIT 200');
admin_head('Avis', 'avis.php');
?>
<h1>Avis clients</h1>
<?php if (!$list) echo '<p class="muted">Aucun avis.</p>'; ?>
<?php foreach ($list as $r): ?>
<div class="panel">
  <p><?= status_tag($r['status']) ?> <?= stars((int)$r['rating']) ?> <strong><?= e($r['author']) ?></strong><?= $r['pname'] ? ' <span class="small">· ' . e($r['pname']) . '</span>' : '' ?></p>
  <p><?= nl2br(e($r['text'])) ?></p>
  <div class="actions">
    <?php foreach ($r['status'] === 'validé' ? ['hide' => 'Dépublier'] : ['ok' => 'Publier'] as $act => $lbl): ?>
    <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><input type="hidden" name="action" value="<?= $act ?>"><button class="btn small <?= $act === 'ok' ? '' : 'ghost' ?>" type="submit"><?= $lbl ?></button></form>
    <?php endforeach; ?>
    <form method="post" class="inline" onsubmit="return confirm('Supprimer cet avis ?')"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><input type="hidden" name="action" value="delete"><button class="btn small danger" type="submit">Supprimer</button></form>
  </div>
</div>
<?php endforeach; ?>
<details class="panel"><summary><strong>Ajouter un avis reçu ailleurs (Instagram, message…)</strong></summary>
  <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="add">
    <label>Prénom</label><input type="text" name="author" required>
    <label>Note</label><select name="rating"><option value="5">★★★★★</option><option value="4">★★★★</option><option value="3">★★★</option></select>
    <label>Avis</label><textarea name="text" required></textarea>
    <p><button class="btn" type="submit">Publier</button></p>
  </form>
</details>
<?php admin_foot();
