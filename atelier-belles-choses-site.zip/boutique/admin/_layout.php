<?php
require_once __DIR__ . '/../inc/bootstrap.php';
require_admin();

function admin_head(string $title, string $active = ''): void
{
    $nav = ['index.php' => 'Accueil', 'produits.php' => 'Produits', 'commandes.php' => 'Commandes', 'demandes.php' => 'Sur mesure', 'avis.php' => 'Avis', 'reglages.php' => 'Réglages'];
    ?><!doctype html>
<html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title><?= e($title) ?> | Administration</title>
<link rel="stylesheet" href="<?= url('assets/style.css') ?>"></head><body>
<div class="admin-nav"><div class="wrap">
<?php foreach ($nav as $f => $l): ?><a class="<?= $active === $f ? 'on' : '' ?>" href="<?= url('admin/' . $f) ?>"><?= $l ?></a><?php endforeach; ?>
<span class="sp"></span><a href="<?= url() ?>" target="_blank">Voir le site</a><a href="<?= url('admin/logout.php') ?>">Quitter</a>
</div></div>
<main class="wrap" style="padding-top:20px;padding-bottom:50px">
<?php flash_show();
}
function admin_foot(): void
{
    echo '</main></body></html>';
}
function status_tag(string $s): string
{
    $c = match ($s) { 'payée', 'nouvelle', 'en attente' => 'warn', 'terminée', 'expédiée', 'validé', 'traitée' => 'good', 'annulée' => 'bad', default => '' };
    return '<span class="tag ' . $c . '">' . e($s) . '</span>';
}
