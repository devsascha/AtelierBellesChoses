<?php
require __DIR__ . '/_layout.php';
$text = ['shop_name', 'tagline', 'email_contact', 'phone', 'instagram_url', 'owner_name', 'siret', 'address', 'categories', 'shipping_label', 'pickup_text', 'delay_text', 'story_title', 'story_text', 'mediator'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    if (post('action') === 'password') {
        $new = (string)($_POST['new'] ?? '');
        if (!password_verify((string)($_POST['old'] ?? ''), setting('admin_hash'))) {
            flash('Ancien mot de passe incorrect.', 'err');
        } elseif (mb_strlen($new) < 10) {
            flash('Le nouveau mot de passe doit faire au moins 10 caractères.', 'err');
        } else {
            set_setting('admin_hash', password_hash($new, PASSWORD_DEFAULT));
            flash('Mot de passe changé.');
        }
        redirect('reglages.php');
    }
    foreach ($text as $k) {
        if (isset($_POST[$k])) {
            set_setting($k, post($k));
        }
    }
    $insta = setting('instagram_url');
    if ($insta !== '' && !preg_match('#^https?://#i', $insta)) {
        set_setting('instagram_url', 'https://' . $insta);
    }
    set_setting('shipping_cents', (string)parse_price(post('shipping')));
    set_setting('free_from_cents', (string)parse_price(post('free_from')));
    set_setting('pickup_enabled', isset($_POST['pickup_enabled']) ? '1' : '0');
    if (!empty($_FILES['story_photo']['tmp_name']) && $_FILES['story_photo']['error'] === UPLOAD_ERR_OK) {
        $f = save_image($_FILES['story_photo']['tmp_name']);
        if ($f) {
            $old = setting('story_photo');
            if ($old) @unlink(ROOT . '/uploads/' . basename($old));
            set_setting('story_photo', $f);
        } else {
            flash('Photo illisible (JPG, PNG ou WebP).', 'err');
        }
    }
    flash('Réglages enregistrés.');
    redirect('reglages.php');
}
function val(string $k): string { return e(setting($k)); }
admin_head('Réglages', 'reglages.php');
?>
<h1>Réglages</h1>
<form method="post" enctype="multipart/form-data"><?= csrf_field() ?>
<div class="panel"><h2 style="margin-top:0">La boutique</h2>
  <label>Nom de la boutique</label><input type="text" name="shop_name" value="<?= val('shop_name') ?>">
  <label>Phrase d'accroche</label><input type="text" name="tagline" value="<?= val('tagline') ?>">
  <label>E-mail de contact</label><input type="email" name="email_contact" value="<?= val('email_contact') ?>">
  <label>Téléphone (facultatif)</label><input type="text" name="phone" value="<?= val('phone') ?>">
  <label>Lien Instagram</label><input type="text" name="instagram_url" value="<?= val('instagram_url') ?>" placeholder="https://www.instagram.com/votre_compte"><p class="hint">Affiché en bas de chaque page.</p>
  <label>Catégories de produits</label><input type="text" name="categories" value="<?= val('categories') ?>"><p class="hint">Séparées par des virgules : Pulls, Pantalons, Chouchous…</p>
</div>
<div class="panel"><h2 style="margin-top:0">Livraison</h2>
  <label>Nom de la livraison à domicile</label><input type="text" name="shipping_label" value="<?= val('shipping_label') ?>">
  <div class="row2">
    <div><label>Frais de livraison (€)</label><input type="text" name="shipping" inputmode="decimal" value="<?= e(number_format((int)setting('shipping_cents') / 100, 2, ',', '')) ?>"></div>
    <div><label>Livraison offerte dès (€)</label><input type="text" name="free_from" inputmode="decimal" value="<?= (int)setting('free_from_cents') ? e(number_format((int)setting('free_from_cents') / 100, 2, ',', '')) : '' ?>"><p class="hint">Laisser vide pour ne jamais offrir.</p></div>
  </div>
  <label>Délai affiché</label><input type="text" name="delay_text" value="<?= val('delay_text') ?>">
  <label class="check"><input type="checkbox" name="pickup_enabled" <?= setting('pickup_enabled') === '1' ? 'checked' : '' ?>> <span>Proposer le retrait en main propre (gratuit)</span></label>
  <label>Texte du retrait</label><input type="text" name="pickup_text" value="<?= val('pickup_text') ?>">
</div>
<div class="panel"><h2 style="margin-top:0">Page « Mon histoire »</h2>
  <label>Titre</label><input type="text" name="story_title" value="<?= val('story_title') ?>">
  <label>Texte</label><textarea name="story_text" style="min-height:200px"><?= val('story_text') ?></textarea>
  <label>Photo</label><?php if (setting('story_photo')): ?><img src="<?= url('uploads/' . val('story_photo')) ?>" alt="" style="width:140px;border-radius:10px;margin-bottom:8px"><?php endif; ?><input type="file" name="story_photo" accept="image/*">
</div>
<div class="panel"><h2 style="margin-top:0">Informations légales</h2>
  <p class="hint">Affichées dans les mentions légales et les CGV.</p>
  <label>Nom et prénom</label><input type="text" name="owner_name" value="<?= val('owner_name') ?>">
  <label>SIRET</label><input type="text" name="siret" value="<?= val('siret') ?>">
  <label>Adresse de l'entreprise</label><input type="text" name="address" value="<?= val('address') ?>">
  <label>Médiateur de la consommation</label><input type="text" name="mediator" value="<?= val('mediator') ?>"><p class="hint">Obligatoire : à choisir auprès d'un médiateur agréé.</p>
</div>
<p><button class="btn" type="submit">Enregistrer les réglages</button></p>
</form>
<form method="post" class="panel"><?= csrf_field() ?><input type="hidden" name="action" value="password"><h2 style="margin-top:0">Changer le mot de passe</h2>
  <label>Ancien mot de passe</label><input type="password" name="old" required autocomplete="current-password">
  <label>Nouveau mot de passe (10 caractères minimum)</label><input type="password" name="new" required autocomplete="new-password">
  <p><button class="btn ghost" type="submit">Changer</button></p>
</form>
<?php admin_foot();
