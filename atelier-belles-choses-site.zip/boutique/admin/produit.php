<?php
require __DIR__ . '/_layout.php';
$id = (int)($_GET['id'] ?? 0);
$p = $id ? row('SELECT * FROM products WHERE id = ?', [$id]) : null;
if ($id && !$p) {
    redirect('produits.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $a = post('action', 'save');
    if ($a === 'delimg' && $p) {
        $im = row('SELECT * FROM product_images WHERE id = ? AND product_id = ?', [(int)post('img'), $id]);
        if ($im) {
            @unlink(ROOT . '/uploads/' . $im['file']);
            run('DELETE FROM product_images WHERE id = ?', [$im['id']]);
            flash('Photo supprimée.');
        }
        redirect('produit.php?id=' . $id);
    }
    if ($a === 'firstimg' && $p) {
        run('UPDATE product_images SET position = position + 1 WHERE product_id = ?', [$id]);
        run('UPDATE product_images SET position = 0 WHERE id = ? AND product_id = ?', [(int)post('img'), $id]);
        flash('Photo principale modifiée.');
        redirect('produit.php?id=' . $id);
    }
    $name = post('name');
    if ($name === '') {
        flash('Le nom est obligatoire.', 'err');
        redirect('produit.php' . ($id ? '?id=' . $id : ''));
    }
    $data = [$name, post('category'), post('description'), parse_price(post('price')), max(0, (int)post('stock')), isset($_POST['made_to_order']) ? 1 : 0,
        post('sizes'), post('colors'), post('fabrics'), isset($_POST['active']) ? 1 : 0];
    if ($p) {
        run('UPDATE products SET name=?, category=?, description=?, price_cents=?, stock=?, made_to_order=?, sizes=?, colors=?, fabrics=?, active=? WHERE id=?', [...$data, $id]);
    } else {
        run('INSERT INTO products (name, category, description, price_cents, stock, made_to_order, sizes, colors, fabrics, active) VALUES (?,?,?,?,?,?,?,?,?,?)', $data);
        $id = (int)db()->lastInsertId();
    }
    $files = $_FILES['photos'] ?? null;
    $added = 0;
    if ($files && is_array($files['tmp_name'])) {
        $pos = (int)(row('SELECT COALESCE(MAX(position), -1) + 1 AS n FROM product_images WHERE product_id = ?', [$id])['n']);
        foreach ($files['tmp_name'] as $i => $tmp) {
            if (($files['error'][$i] ?? 4) === UPLOAD_ERR_OK && is_uploaded_file($tmp)) {
                $f = save_image($tmp);
                if ($f) {
                    run('INSERT INTO product_images (product_id, file, position) VALUES (?,?,?)', [$id, $f, $pos++]);
                    $added++;
                } else {
                    flash('Une photo n\'a pas pu être lue (formats acceptés : JPG, PNG, WebP).', 'err');
                }
            }
        }
    }
    flash('Produit enregistré' . ($added ? " ($added photo(s) ajoutée(s))" : '') . '.');
    redirect('produit.php?id=' . $id);
}
$v = $p ?: ['name' => '', 'category' => '', 'description' => '', 'price_cents' => 0, 'stock' => 1, 'made_to_order' => 0, 'sizes' => '', 'colors' => '', 'fabrics' => '', 'active' => 1];
$imgs = $p ? product_images($id) : [];
admin_head($p ? 'Modifier un produit' : 'Nouveau produit', 'produits.php');
?>
<h1><?= $p ? 'Modifier : ' . e($p['name']) : 'Nouveau produit' ?></h1>
<form method="post" enctype="multipart/form-data" class="panel"><?= csrf_field() ?>
  <label>Nom du produit</label><input type="text" name="name" value="<?= e($v['name']) ?>" required>
  <div class="row2">
    <div><label>Catégorie</label><select name="category"><?php foreach (opts(setting('categories')) as $c): ?><option <?= $v['category'] === $c ? 'selected' : '' ?>><?= e($c) ?></option><?php endforeach; ?></select></div>
    <div><label>Prix (€)</label><input type="text" name="price" inputmode="decimal" value="<?= $v['price_cents'] ? e(number_format($v['price_cents'] / 100, 2, ',', '')) : '' ?>" required></div>
  </div>
  <label>Description</label><textarea name="description"><?= e($v['description']) ?></textarea>
  <div class="row2">
    <div><label>Stock (nombre en vente)</label><input type="number" name="stock" min="0" value="<?= (int)$v['stock'] ?>"></div>
    <div><label>&nbsp;</label><label class="check"><input type="checkbox" name="made_to_order" <?= $v['made_to_order'] ? 'checked' : '' ?>> <span>Fait sur commande (pas de limite de stock)</span></label></div>
  </div>
  <label>Tailles / formats</label><input type="text" name="sizes" value="<?= e($v['sizes']) ?>" placeholder="S, M, L"><p class="hint">Séparez par des virgules. Laissez vide s'il n'y a pas de choix.</p>
  <label>Couleurs</label><input type="text" name="colors" value="<?= e($v['colors']) ?>" placeholder="Rose poudré, Écru"><p class="hint">Séparez par des virgules.</p>
  <label>Tissus</label><input type="text" name="fabrics" value="<?= e($v['fabrics']) ?>" placeholder="Lin, Coton à fleurs"><p class="hint">Séparez par des virgules.</p>
  <label>Ajouter des photos</label><input type="file" name="photos[]" accept="image/*" multiple>
  <label class="check"><input type="checkbox" name="active" <?= $v['active'] ? 'checked' : '' ?>> <span>Visible sur le site</span></label>
  <p class="actions"><button class="btn" type="submit">Enregistrer</button> <a class="btn ghost" href="produits.php">Retour</a></p>
</form>
<?php if ($imgs): ?>
<h2>Photos</h2>
<div class="imgs">
<?php foreach ($imgs as $k => $im): ?>
  <figure><img src="<?= url('uploads/' . $im['file']) ?>" alt="">
    <?php if ($k === 0): ?><span class="tag good">Principale</span><?php else: ?>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="firstimg"><input type="hidden" name="img" value="<?= (int)$im['id'] ?>"><button class="btn small ghost" type="submit">Mettre en 1re</button></form><?php endif; ?>
    <form method="post" onsubmit="return confirm('Supprimer cette photo ?')"><?= csrf_field() ?><input type="hidden" name="action" value="delimg"><input type="hidden" name="img" value="<?= (int)$im['id'] ?>"><button class="btn small danger" type="submit" style="margin-top:4px">Supprimer</button></form>
  </figure>
<?php endforeach; ?>
</div>
<?php endif; ?>
<?php admin_foot();
