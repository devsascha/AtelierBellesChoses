<?php
require __DIR__ . '/../inc/bootstrap.php';
$_SESSION = [];
session_destroy();
redirect(url('admin/login.php'));
