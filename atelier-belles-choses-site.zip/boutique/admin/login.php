<?php
require __DIR__ . '/../inc/bootstrap.php';
if (!empty($_SESSION['admin'])) {
    redirect(url('admin/index.php'));
}
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $_SESSION['tries'] = ($_SESSION['tries'] ?? 0) + 1;
    if ($_SESSION['tries'] > 8) {
        $err = 'Trop d\'essais, réessayez plus tard.';
    } elseif (password_verify((string)($_POST['password'] ?? ''), setting('admin_hash'))) {
        session_regenerate_id(true);
        $_SESSION['admin'] = true;
        $_SESSION['tries'] = 0;
        redirect(url('admin/index.php'));
    } else {
        sleep(1);
        $err = 'Mot de passe incorrect.';
    }
}
?><!doctype html>
<html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex">
<title>Connexion | Administration</title><link rel="stylesheet" href="<?= url('assets/style.css') ?>"></head>
<body><main class="wrap" style="max-width:420px;padding-top:60px">
<h1 style="text-align:center">Espace administration</h1>
<?php if ($err): ?><div class="flash err"><?= e($err) ?></div><?php endif; ?>
<form method="post" class="panel"><?= csrf_field() ?>
  <label for="p">Mot de passe</label><input id="p" type="password" name="password" required autofocus>
  <p><button class="btn block" type="submit">Se connecter</button></p>
</form></main></body></html>
