<?php
require __DIR__ . '/_layout.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $id = (int)post('id');
    $a = post('action');
    if ($a === 'toggle') {
        run('UPDATE products SET active = 1 - active WHERE id = ?', [$id]);
        flash('Visibilité modifiée.');
    } elseif ($a === 'stock') {
        run('UPDATE products SET stock = ? WHERE id = ?', [max(0, (int)post('stock')), $id]);
        flash('Stock mis à jour.');
    } elseif ($a === 'delete') {
        foreach (product_images($id) as $im) {
            @unlink(ROOT . '/uploads/' . $im['file']);
        }
        run('DELETE FROM product_images WHERE product_id = ?', [$id]);
        run('DELETE FROM products WHERE id = ?', [$id]);
        flash('Produit supprimé.');
    }
    redirect('produits.php');
}
$list = rows('SELECT * FROM products ORDER BY id DESC');
admin_head('Produits', 'produits.php');
?>
<h1>Mes produits</h1>
<p><a class="btn" href="produit.php">+ Ajouter un produit</a></p>
<?php if (!$list) echo '<p class="muted">Aucun produit pour l\'instant.</p>'; ?>
<div class="scroll"><table>
<?php foreach ($list as $p): $img = cover((int)$p['id']); ?>
<tr>
  <td style="width:70px"><?php if ($img): ?><img class="cart-img" src="<?= e($img) ?>" alt=""><?php endif; ?></td>
  <td><a href="produit.php?id=<?= (int)$p['id'] ?>"><strong><?= e($p['name']) ?></strong></a><br><span class="small"><?= e($p['category']) ?> · <?= money((int)$p['price_cents']) ?></span><br><?= $p['active'] ? '<span class="tag good">en ligne</span>' : '<span class="tag">masqué</span>' ?><?= $p['made_to_order'] ? ' <span class="tag">sur commande</span>' : '' ?></td>
  <td style="min-width:130px">
    <?php if (!$p['made_to_order']): ?>
    <form method="post" class="actions" style="flex-wrap:nowrap"><?= csrf_field() ?><input type="hidden" name="action" value="stock"><input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
      <input type="number" name="stock" min="0" value="<?= (int)$p['stock'] ?>" style="width:70px"><button class="btn small ghost" type="submit">OK</button></form>
    <span class="small">stock</span>
    <?php endif; ?>
  </td>
  <td class="actions">
    <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int)$p['id'] ?>"><button class="btn small ghost" type="submit"><?= $p['active'] ? 'Masquer' : 'Afficher' ?></button></form>
    <form method="post" class="inline" onsubmit="return confirm('Supprimer définitivement ce produit ?')"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$p['id'] ?>"><button class="btn small danger" type="submit">Supprimer</button></form>
  </td>
</tr>
<?php endforeach; ?>
</table></div>
<?php admin_foot();
