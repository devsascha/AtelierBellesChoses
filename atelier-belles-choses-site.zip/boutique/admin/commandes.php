<?php
require __DIR__ . '/_layout.php';
$id = (int)($_GET['id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $oid = (int)post('id');
    $o = row('SELECT * FROM orders WHERE id = ?', [$oid]);
    if ($o) {
        $st = post('status');
        $tracking = post('tracking');
        if (in_array($st, ORDER_STATUSES, true)) {
            run('UPDATE orders SET status = ?, tracking = ? WHERE id = ?', [$st, $tracking, $oid]);
            if ($st === 'expédiée' && $o['status'] !== 'expédiée') {
                send_mail($o['email'], 'Votre commande ' . $o['ref'] . ' est expédiée', "Bonjour {$o['name']},\n\nVotre commande {$o['ref']} vient d'être expédiée." . ($tracking ? "\nNuméro de suivi : $tracking" : '') . "\n\nMerci pour votre confiance,\n" . setting('shop_name'), setting('email_contact'));
            }
            if ($st === 'annulée' && $o['status'] !== 'annulée' && $o['status'] !== 'en attente de paiement') {
                foreach (rows('SELECT * FROM order_items WHERE order_id = ?', [$oid]) as $i) {
                    run('UPDATE products SET stock = stock + ? WHERE id = ? AND made_to_order = 0', [$i['qty'], $i['product_id']]);
                }
                flash('Commande annulée : le stock a été remis. Le remboursement se fait depuis le tableau de bord Stripe.');
            } else {
                flash('Commande mise à jour.');
            }
        }
    }
    redirect('commandes.php?id=' . $oid);
}

if ($id && ($o = row('SELECT * FROM orders WHERE id = ?', [$id]))) {
    $items = rows('SELECT * FROM order_items WHERE order_id = ?', [$id]);
    admin_head('Commande ' . $o['ref'], 'commandes.php');
    ?>
<p><a href="commandes.php">← Toutes les commandes</a></p>
<h1>Commande <?= e($o['ref']) ?> <?= status_tag($o['status']) ?></h1>
<div class="panel">
  <p><strong><?= e($o['name']) ?></strong><br><a href="mailto:<?= e($o['email']) ?>"><?= e($o['email']) ?></a><?= $o['phone'] ? '<br>' . e($o['phone']) : '' ?></p>
  <p><?php if ($o['delivery'] === 'domicile'): ?><strong>Livraison à domicile</strong><br><?= e($o['address']) ?><br><?= e($o['zip'] . ' ' . $o['city']) ?><?php else: ?><strong>Retrait en main propre</strong><?php endif; ?></p>
  <?php if ($o['note']): ?><p><strong>Message :</strong> <?= nl2br(e($o['note'])) ?></p><?php endif; ?>
  <p class="small">Passée le <?= e($o['created_at']) ?><?= $o['paid_at'] ? ' · payée le ' . e($o['paid_at']) : '' ?></p>
</div>
<div class="scroll"><table>
<?php foreach ($items as $i): ?><tr><td><?= (int)$i['qty'] ?> × <strong><?= e($i['name']) ?></strong><br><span class="small"><?= e(implode(' · ', array_filter([$i['size'], $i['color'], $i['fabric']]))) ?></span></td><td style="text-align:right"><?= money((int)$i['unit_cents'] * (int)$i['qty']) ?></td></tr><?php endforeach; ?>
<tr><td>Livraison</td><td style="text-align:right"><?= money((int)$o['shipping_cents']) ?></td></tr>
<tr><td><strong>Total</strong></td><td style="text-align:right"><strong><?= money((int)$o['total_cents']) ?></strong></td></tr>
</table></div>
<form method="post" class="panel"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$o['id'] ?>">
  <label>Statut</label><select name="status"><?php foreach (ORDER_STATUSES as $s): ?><option <?= $o['status'] === $s ? 'selected' : '' ?>><?= e($s) ?></option><?php endforeach; ?></select>
  <label>Numéro de suivi (facultatif)</label><input type="text" name="tracking" value="<?= e($o['tracking']) ?>">
  <p class="hint">En passant la commande en « expédiée », le client reçoit un e-mail automatique.</p>
  <p><button class="btn" type="submit">Enregistrer</button></p>
</form>
<?php
    admin_foot();
    exit;
}

$f = (string)($_GET['f'] ?? '');
$list = $f !== '' ? rows('SELECT * FROM orders WHERE status = ? ORDER BY id DESC LIMIT 200', [$f]) : rows('SELECT * FROM orders ORDER BY id DESC LIMIT 200');
admin_head('Commandes', 'commandes.php');
?>
<h1>Commandes</h1>
<div class="cats"><a class="chip <?= $f === '' ? 'on' : '' ?>" href="commandes.php">Toutes</a><?php foreach (ORDER_STATUSES as $s): ?><a class="chip <?= $f === $s ? 'on' : '' ?>" href="commandes.php?f=<?= urlencode($s) ?>"><?= e($s) ?></a><?php endforeach; ?></div>
<?php if (!$list) echo '<p class="muted">Aucune commande.</p>'; ?>
<div class="scroll"><table>
<?php foreach ($list as $o): ?>
<tr><td><a href="commandes.php?id=<?= (int)$o['id'] ?>"><strong><?= e($o['ref']) ?></strong></a><br><span class="small"><?= e($o['created_at']) ?></span></td><td><?= e($o['name']) ?></td><td><?= status_tag($o['status']) ?></td><td style="text-align:right"><?= money((int)$o['total_cents']) ?></td></tr>
<?php endforeach; ?>
</table></div>
<?php admin_foot();
