<?php
require __DIR__ . '/_layout.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $id = (int)post('id');
    if (post('action') === 'delete') {
        run('DELETE FROM requests WHERE id = ?', [$id]);
        flash('Demande supprimée.');
    } else {
        run("UPDATE requests SET status = CASE status WHEN 'nouvelle' THEN 'traitée' ELSE 'nouvelle' END WHERE id = ?", [$id]);
    }
    redirect('demandes.php');
}
$list = rows('SELECT * FROM requests ORDER BY id DESC LIMIT 200');
admin_head('Demandes sur mesure', 'demandes.php');
?>
<h1>Demandes sur mesure</h1>
<?php if (!$list) echo '<p class="muted">Aucune demande.</p>'; ?>
<?php foreach ($list as $r): ?>
<div class="panel">
  <p><?= status_tag($r['status']) ?> <strong><?= e($r['name']) ?></strong> · <?= e($r['type']) ?> <span class="small">· <?= e($r['created_at']) ?></span></p>
  <p><a href="mailto:<?= e($r['email']) ?>?subject=<?= rawurlencode('Votre demande sur mesure') ?>"><?= e($r['email']) ?></a><?= $r['phone'] ? ' · ' . e($r['phone']) : '' ?></p>
  <p class="desc"><?= e($r['details']) ?></p>
  <?php if ($r['measures']): ?><p class="desc"><strong>Mensurations :</strong> <?= e($r['measures']) ?></p><?php endif; ?>
  <div class="actions">
    <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><button class="btn small ghost" type="submit"><?= $r['status'] === 'nouvelle' ? 'Marquer comme traitée' : 'Remettre en nouvelle' ?></button></form>
    <form method="post" class="inline" onsubmit="return confirm('Supprimer cette demande ?')"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><button class="btn small danger" type="submit">Supprimer</button></form>
  </div>
</div>
<?php endforeach; ?>
<?php admin_foot();
