<?php
require __DIR__ . '/inc/layout.php';
site_head('Mentions légales');
?>
<h1>Mentions légales</h1>
<h2>Éditeur du site</h2>
<p><?= e(setting('shop_name')) ?>, entreprise individuelle (micro-entreprise)<br>
Responsable de la publication : <?= e(setting('owner_name') ?: 'à compléter') ?><br>
SIRET : <?= e(setting('siret') ?: 'à compléter') ?><br>
Adresse : <?= e(setting('address') ?: 'à compléter') ?><br>
E-mail : <a href="mailto:<?= e(setting('email_contact')) ?>"><?= e(setting('email_contact')) ?></a><?php if (setting('phone')): ?><br>Téléphone : <?= e(setting('phone')) ?><?php endif; ?></p>
<p>TVA non applicable, article 293 B du CGI.</p>
<h2>Hébergement</h2>
<p>OVH SAS, 2 rue Kellermann, 59100 Roubaix, France.</p>
<h2>Propriété intellectuelle</h2>
<p>Les photos, textes, modèles et créations présentés sur ce site sont la propriété de <?= e(setting('shop_name')) ?>. Toute reproduction sans autorisation est interdite.</p>
<h2>Paiement</h2>
<p>Les paiements par carte sont traités par Stripe. Aucune donnée bancaire n'est enregistrée sur ce site.</p>
<?php site_foot();
