<?php
require __DIR__ . '/inc/layout.php';
site_head(setting('story_title'));
$photo = setting('story_photo');
?>
<div class="product">
  <div><?php if ($photo): ?><img src="<?= url('uploads/' . e($photo)) ?>" alt="" style="border-radius:var(--radius);width:100%"><?php endif; ?></div>
  <div>
    <h1><?= e(setting('story_title')) ?></h1>
    <p class="desc"><?= e(setting('story_text')) ?></p>
    <p><a class="btn" href="<?= url('boutique.php') ?>">Découvrir mes créations</a></p>
  </div>
</div>
<?php site_foot();
