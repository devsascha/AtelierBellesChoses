<?php
require __DIR__ . '/inc/layout.php';

[$lines, $sub] = cart_lines();
if (!$lines) {
    redirect(url('panier.php'));
}
$pickup = setting('pickup_enabled') === '1';
$errors = [];
$v = ['name' => '', 'email' => '', 'phone' => '', 'delivery' => 'domicile', 'address' => '', 'zip' => '', 'city' => '', 'note' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    foreach ($v as $k => $_) {
        $v[$k] = mb_substr(post($k, $v[$k]), 0, 300);
    }
    if ($v['delivery'] === 'retrait' && !$pickup) {
        $v['delivery'] = 'domicile';
    }
    if ($v['name'] === '') $errors[] = 'Merci d\'indiquer votre nom.';
    if (!filter_var($v['email'], FILTER_VALIDATE_EMAIL)) $errors[] = 'Adresse e-mail invalide.';
    if ($v['delivery'] === 'domicile' && ($v['address'] === '' || !preg_match('/^\d{5}$/', $v['zip']) || $v['city'] === '')) {
        $errors[] = 'Adresse de livraison incomplète (code postal à 5 chiffres).';
    }
    if (post('cgv') !== '1') $errors[] = 'Merci d\'accepter les conditions générales de vente.';

    if (!$errors) {
        $ship = shipping_for($v['delivery'], $sub);
        $total = $sub + $ship;
        $ref = 'BC' . date('ymd') . strtoupper(bin2hex(random_bytes(2)));
        $pdo = db();
        $pdo->beginTransaction();
        run('INSERT INTO orders (ref, name, email, phone, delivery, address, zip, city, shipping_cents, total_cents, note) VALUES (?,?,?,?,?,?,?,?,?,?,?)',
            [$ref, $v['name'], $v['email'], $v['phone'], $v['delivery'], $v['address'], $v['zip'], $v['city'], $ship, $total, $v['note']]);
        $oid = (int)$pdo->lastInsertId();
        foreach ($lines as $l) {
            run('INSERT INTO order_items (order_id, product_id, name, size, color, fabric, qty, unit_cents) VALUES (?,?,?,?,?,?,?,?)',
                [$oid, $l['p']['id'], $l['p']['name'], $l['size'], $l['color'], $l['fabric'], $l['qty'], $l['unit']]);
        }
        $pdo->commit();

        $params = ['mode' => 'payment', 'locale' => 'fr', 'customer_email' => $v['email'], 'client_reference_id' => $ref,
            'success_url' => base_url() . '/merci.php?ref=' . $ref . '&session_id={CHECKOUT_SESSION_ID}',
            'cancel_url' => base_url() . '/panier.php', 'metadata' => ['order_id' => $oid, 'ref' => $ref], 'line_items' => []];
        foreach ($lines as $l) {
            $opt = implode(' / ', array_filter([$l['size'], $l['color'], $l['fabric']]));
            $pd = ['currency' => 'eur', 'unit_amount' => $l['unit'], 'product_data' => ['name' => $l['p']['name']]];
            if ($opt !== '') $pd['product_data']['description'] = $opt;
            $params['line_items'][] = ['quantity' => $l['qty'], 'price_data' => $pd];
        }
        if ($ship > 0) {
            $params['line_items'][] = ['quantity' => 1, 'price_data' => ['currency' => 'eur', 'unit_amount' => $ship, 'product_data' => ['name' => 'Livraison']]];
        }
        try {
            $s = stripe_call('POST', 'checkout/sessions', $params);
            run('UPDATE orders SET stripe_session = ? WHERE id = ?', [$s['id'], $oid]);
            redirect($s['url']);
        } catch (Throwable $ex) {
            error_log('Stripe: ' . $ex->getMessage());
            run("UPDATE orders SET status = 'annulée' WHERE id = ?", [$oid]);
            $errors[] = 'Le paiement en ligne n\'est pas disponible pour le moment. Merci de réessayer ou de nous contacter.';
        }
    }
}
$ship = shipping_for($v['delivery'], $sub);
site_head('Commande');
?>
<h1>Finaliser ma commande</h1>
<?php foreach ($errors as $er): ?><div class="flash err"><?= e($er) ?></div><?php endforeach; ?>
<form method="post" class="product" style="align-items:start"><?= csrf_field() ?>
  <div>
    <h2 style="margin-top:0">Mes coordonnées</h2>
    <label>Nom et prénom</label><input type="text" name="name" value="<?= e($v['name']) ?>" required autocomplete="name">
    <div class="row2">
      <div><label>E-mail</label><input type="email" name="email" value="<?= e($v['email']) ?>" required autocomplete="email"></div>
      <div><label>Téléphone</label><input type="tel" name="phone" value="<?= e($v['phone']) ?>" autocomplete="tel"></div>
    </div>
    <h2>Livraison</h2>
    <label class="check"><input type="radio" name="delivery" value="domicile" <?= $v['delivery'] === 'domicile' ? 'checked' : '' ?>> <span><?= e(setting('shipping_label')) ?> : <b><?= $ship ? money($ship) : 'offerte' ?></b><br><span class="small"><?= e(setting('delay_text')) ?></span></span></label>
    <?php if ($pickup): ?><label class="check"><input type="radio" name="delivery" value="retrait" <?= $v['delivery'] === 'retrait' ? 'checked' : '' ?>> <span><?= e(setting('pickup_text')) ?></span></label><?php endif; ?>
    <label>Adresse</label><input type="text" name="address" value="<?= e($v['address']) ?>" autocomplete="street-address">
    <div class="row2">
      <div><label>Code postal</label><input type="text" name="zip" value="<?= e($v['zip']) ?>" inputmode="numeric" maxlength="5" autocomplete="postal-code"></div>
      <div><label>Ville</label><input type="text" name="city" value="<?= e($v['city']) ?>" autocomplete="address-level2"></div>
    </div>
    <p class="hint">Adresse inutile en cas de retrait.</p>
    <label>Un message pour l'atelier (facultatif)</label><textarea name="note"><?= e($v['note']) ?></textarea>
    <label class="check"><input type="checkbox" name="cgv" value="1" required> <span>J'ai lu et j'accepte les <a href="<?= url('cgv.php') ?>" target="_blank">conditions générales de vente</a>.</span></label>
  </div>
  <div class="panel">
    <h2 style="margin-top:0">Récapitulatif</h2>
    <?php foreach ($lines as $l): ?>
      <div style="display:flex;justify-content:space-between;gap:10px;padding:4px 0"><span><?= $l['qty'] ?> × <?= e($l['p']['name']) ?><br><span class="small"><?= e(implode(' · ', array_filter([$l['size'], $l['color'], $l['fabric']]))) ?></span></span><span><?= money($l['total']) ?></span></div>
    <?php endforeach; ?>
    <div class="totals" style="margin-left:0;max-width:none">
      <div><span>Sous-total</span><span><?= money($sub) ?></span></div>
      <div><span>Livraison</span><span><?= $v['delivery'] === 'retrait' ? 'Gratuit' : ($ship ? money($ship) : 'Offerte') ?></span></div>
      <div class="grand"><span>Total</span><span><?= money($sub + ($v['delivery'] === 'retrait' ? 0 : $ship)) ?></span></div>
    </div>
    <p><button class="btn block" type="submit">Payer par carte</button></p>
    <p class="small">Paiement sécurisé par Stripe. Vos données bancaires ne transitent pas par ce site.</p>
  </div>
</form>
<?php site_foot();
