<?php
require __DIR__ . '/inc/layout.php';
$cats = opts(setting('categories'));
$cat = (string)($_GET['cat'] ?? '');
$list = $cat !== ''
    ? rows('SELECT * FROM products WHERE active = 1 AND category = ? ORDER BY id DESC', [$cat])
    : rows('SELECT * FROM products WHERE active = 1 ORDER BY id DESC');
site_head($cat !== '' ? $cat : 'Boutique');
?>
<h1><?= $cat !== '' ? e($cat) : 'La boutique' ?></h1>
<div class="cats">
  <a class="chip <?= $cat === '' ? 'on' : '' ?>" href="<?= url('boutique.php') ?>">Tout</a>
  <?php foreach ($cats as $c): ?><a class="chip <?= $cat === $c ? 'on' : '' ?>" href="<?= url('boutique.php?cat=' . urlencode($c)) ?>"><?= e($c) ?></a><?php endforeach; ?>
</div>
<?php if ($list): ?>
  <div class="grid"><?php foreach ($list as $p) { product_card($p); } ?></div>
<?php else: ?>
  <p class="muted">Aucune création dans cette catégorie pour le moment.</p>
<?php endif; ?>
<?php site_foot();
