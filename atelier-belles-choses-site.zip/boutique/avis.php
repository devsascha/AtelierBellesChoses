<?php
require __DIR__ . '/inc/layout.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    review_submit(null);
    redirect(url('avis.php'));
}
$reviews = rows("SELECT r.*, p.name AS pname FROM reviews r LEFT JOIN products p ON p.id = r.product_id WHERE r.status = 'validé' ORDER BY r.id DESC");
site_head('Avis clients');
?>
<h1>Avis de nos clientes</h1>
<?php foreach ($reviews as $r): ?>
  <div class="review"><?= stars((int)$r['rating']) ?> <strong><?= e($r['author']) ?></strong>
    <?php if ($r['pname']): ?><span class="small"> · <a href="<?= url('produit.php?id=' . (int)$r['product_id']) ?>"><?= e($r['pname']) ?></a></span><?php endif; ?>
    <p><?= nl2br(e($r['text'])) ?></p></div>
<?php endforeach; if (!$reviews) echo '<p class="muted">Aucun avis pour le moment.</p>'; ?>
<h2>Laisser un avis</h2>
<form method="post" class="panel"><?= csrf_field() ?>
  <div class="hp"><input type="text" name="website" tabindex="-1" autocomplete="off"></div>
  <label>Votre prénom</label><input type="text" name="author" required maxlength="60">
  <label>Note</label><select name="rating"><option value="5">★★★★★</option><option value="4">★★★★</option><option value="3">★★★</option><option value="2">★★</option><option value="1">★</option></select>
  <label>Votre avis</label><textarea name="text" required maxlength="1500"></textarea>
  <p class="hint">Les avis sont publiés après validation.</p>
  <p><button class="btn" type="submit">Envoyer mon avis</button></p>
</form>
<?php site_foot();
