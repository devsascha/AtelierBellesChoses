<?php
require __DIR__ . '/inc/layout.php';
$done = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    if (post('website') === '') {
        $name = mb_substr(post('name'), 0, 100);
        $email = mb_substr(post('email'), 0, 150);
        $details = mb_substr(post('details'), 0, 3000);
        if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || $details === '') {
            flash('Merci de renseigner votre nom, un e-mail valide et votre demande.', 'err');
        } else {
            $type = mb_substr(post('type'), 0, 80);
            $phone = mb_substr(post('phone'), 0, 30);
            $measures = mb_substr(post('measures'), 0, 1000);
            run('INSERT INTO requests (name, email, phone, type, details, measures) VALUES (?,?,?,?,?,?)', [$name, $email, $phone, $type, $details, $measures]);
            notify_owner('Demande sur mesure de ' . $name, "Type : $type\nTéléphone : $phone\n\n$details\n\nMensurations : $measures", $email);
            send_mail($email, 'Votre demande sur mesure - ' . setting('shop_name'), "Bonjour $name,\n\nNous avons bien reçu votre demande et reviendrons vers vous rapidement avec une proposition et un devis.\n\nÀ bientôt,\n" . setting('shop_name'), setting('email_contact'));
            $done = true;
        }
    } else {
        $done = true;
    }
}
site_head('Sur mesure');
?>
<h1>Une création sur mesure</h1>
<p>Une taille particulière, un tissu précis, une idée de cadeau ? Décrivez votre envie : je reviens vers vous avec une proposition et un devis, sans engagement.</p>
<?php if ($done): ?>
  <div class="panel"><strong>Merci !</strong> Votre demande est bien partie. Vous recevrez une réponse rapidement par e-mail.</div>
<?php else: ?>
<form method="post" class="panel"><?= csrf_field() ?>
  <div class="hp"><input type="text" name="website" tabindex="-1" autocomplete="off"></div>
  <div class="row2">
    <div><label>Nom et prénom</label><input type="text" name="name" required value="<?= e(post('name')) ?>"></div>
    <div><label>E-mail</label><input type="email" name="email" required value="<?= e(post('email')) ?>"></div>
  </div>
  <div class="row2">
    <div><label>Téléphone (facultatif)</label><input type="tel" name="phone" value="<?= e(post('phone')) ?>"></div>
    <div><label>Type de pièce</label>
      <select name="type"><?php foreach (array_merge(opts(setting('categories')), ['Cadeau de naissance', 'Autre']) as $c): ?><option><?= e($c) ?></option><?php endforeach; ?></select></div>
  </div>
  <label>Votre demande</label>
  <textarea name="details" required placeholder="Couleurs, tissu souhaité, occasion, date limite…"><?= e(post('details')) ?></textarea>
  <label>Mensurations ou taille (facultatif)</label>
  <textarea name="measures" style="min-height:70px" placeholder="Taille habituelle, tour de poitrine, de taille, longueur…"><?= e(post('measures')) ?></textarea>
  <p><button class="btn" type="submit">Envoyer ma demande</button></p>
</form>
<?php endif; ?>
<?php site_foot();
