<?php
require __DIR__ . '/inc/layout.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = post('action');
    if ($action === 'add') {
        $pid = (int)post('pid');
        $p = row('SELECT * FROM products WHERE id = ? AND active = 1', [$pid]);
        if ($p && in_stock($p)) {
            $size = post('size');
            $color = post('color');
            $fabric = post('fabric');
            if (($size !== '' && !in_array($size, opts($p['sizes']), true)) || ($color !== '' && !in_array($color, opts($p['colors']), true)) || ($fabric !== '' && !in_array($fabric, opts($p['fabrics']), true))) {
                flash('Option invalide.', 'err');
                redirect(url('produit.php?id=' . $pid));
            }
            $key = cart_key($pid, $size, $color, $fabric);
            $qty = max(1, min(20, (int)post('qty', '1')));
            $cur = (int)($_SESSION['cart'][$key]['qty'] ?? 0);
            $new = $cur + $qty;
            if (!$p['made_to_order'] && $new > (int)$p['stock']) {
                $new = (int)$p['stock'];
                flash('Quantité limitée au stock disponible.', 'err');
            }
            $_SESSION['cart'][$key] = ['pid' => $pid, 'size' => $size, 'color' => $color, 'fabric' => $fabric, 'qty' => $new];
            flash('Ajouté au panier.');
        }
    } elseif ($action === 'update') {
        foreach ($_POST['qty'] ?? [] as $key => $q) {
            if (isset($_SESSION['cart'][$key])) {
                $q = (int)$q;
                if ($q < 1) {
                    unset($_SESSION['cart'][$key]);
                } else {
                    $_SESSION['cart'][$key]['qty'] = min($q, 20);
                }
            }
        }
    } elseif ($action === 'remove') {
        unset($_SESSION['cart'][post('key')]);
    }
    redirect(url('panier.php'));
}

[$lines, $total] = cart_lines();
site_head('Panier');
?>
<h1>Mon panier</h1>
<?php if (!$lines): ?>
  <p>Votre panier est vide.</p>
  <p><a class="btn" href="<?= url('boutique.php') ?>">Voir la boutique</a></p>
<?php else: ?>
<form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="update">
<div class="scroll"><table>
  <?php foreach ($lines as $l): $opt = implode(' · ', array_filter([$l['size'], $l['color'], $l['fabric']])); ?>
  <tr>
    <td style="width:76px"><?php if ($l['img']): ?><img class="cart-img" src="<?= e($l['img']) ?>" alt=""><?php endif; ?></td>
    <td><a href="<?= url('produit.php?id=' . (int)$l['p']['id']) ?>"><strong><?= e($l['p']['name']) ?></strong></a><br><span class="small"><?= e($opt) ?></span><br><span class="small"><?= money($l['unit']) ?></span></td>
    <td style="width:90px"><input type="number" min="0" max="20" name="qty[<?= e($l['key']) ?>]" value="<?= $l['qty'] ?>"></td>
    <td style="text-align:right;white-space:nowrap"><?= money($l['total']) ?></td>
  </tr>
  <?php endforeach; ?>
</table></div>
<p class="actions"><button class="btn ghost small" type="submit">Mettre à jour les quantités</button> <span class="small">(0 pour retirer un article)</span></p>
</form>
<div class="totals">
  <div><span>Sous-total</span><b><?= money($total) ?></b></div>
  <div class="small"><span>Livraison</span><span>calculée à l'étape suivante</span></div>
  <p><a class="btn block" href="<?= url('commande.php') ?>">Passer la commande</a></p>
</div>
<?php endif; ?>
<?php site_foot();
