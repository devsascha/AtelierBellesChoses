<?php
require __DIR__ . '/inc/layout.php';
site_head('Politique de confidentialité');
?>
<h1>Politique de confidentialité</h1>
<p>Responsable du traitement : <?= e(setting('shop_name')) ?> (<?= e(setting('email_contact')) ?>).</p>
<h2>Données collectées</h2>
<p>Lors d'une commande, d'une demande sur mesure ou d'un avis, nous collectons les informations que vous saisissez : nom, e-mail, téléphone, adresse de livraison, contenu du message.</p>
<h2>Finalités et bases légales</h2>
<p>Ces données servent uniquement à traiter votre commande ou votre demande (exécution du contrat), à vous contacter à ce sujet, et à respecter nos obligations comptables et légales.</p>
<h2>Destinataires</h2>
<p>Vos données ne sont ni vendues ni cédées. Elles sont accessibles à l'atelier et, pour le strict nécessaire, à Stripe (paiement) et aux transporteurs (livraison).</p>
<h2>Durée de conservation</h2>
<p>Les données de commande sont conservées 10 ans (obligations comptables). Les demandes sur mesure sans suite sont supprimées sous 3 ans.</p>
<h2>Vos droits</h2>
<p>Vous pouvez demander l'accès, la rectification ou la suppression de vos données en écrivant à <a href="mailto:<?= e(setting('email_contact')) ?>"><?= e(setting('email_contact')) ?></a>. Vous pouvez aussi saisir la CNIL (cnil.fr).</p>
<h2>Cookies</h2>
<p>Ce site utilise uniquement un cookie technique de session nécessaire au fonctionnement du panier. Il ne dépose aucun cookie publicitaire ni de mesure d'audience.</p>
<?php site_foot();
