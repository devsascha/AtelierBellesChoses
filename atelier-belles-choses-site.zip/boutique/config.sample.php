<?php
// Copiez ce fichier en config.php puis remplissez les valeurs.
return [
    // Adresse du site, sans slash final (ex : https://www.atelierbellescho.fr). Laisser vide = détection automatique.
    'site_url' => '',

    // Mot de passe admin initial (utilisé uniquement à la 1re installation, à changer ensuite dans Réglages).
    'admin_password' => 'ChangezMoi!2026',

    // Stripe : https://dashboard.stripe.com/apikeys (commencer par les clés de TEST : sk_test_...)
    'stripe_secret'  => '',
    // Stripe : Développeurs > Webhooks > ajouter l'URL https://VOTRE-SITE/webhook.php (événement checkout.session.completed)
    'stripe_webhook_secret' => '',

    // Adresse d'expédition des e-mails du site (doit appartenir au domaine pour éviter les spams)
    'mail_from' => 'contact@exemple.fr',
    // Adresse qui reçoit les notifications (commandes, demandes sur-mesure, avis)
    'mail_notify' => 'contact@exemple.fr',
];
