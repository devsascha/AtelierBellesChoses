# Site de l'Atelier Belles Choses : installation

## 1. Mettre le site en ligne (OVH)
1. Prendre un hébergement OVH avec PHP 8.1 ou plus (l'offre « Perso » suffit) et lier le nom de domaine.
2. Envoyer tout le contenu de ce dossier dans le dossier `www` (FTP ou gestionnaire de fichiers OVH).
3. Copier `config.sample.php` en `config.php` et le remplir (voir ci-dessous).
4. Activer le HTTPS (certificat SSL gratuit dans l'espace OVH).
5. Ouvrir `https://votre-site/admin/` et se connecter avec le mot de passe initial, puis le changer dans **Réglages**.

Aucune base de données à créer : le site crée tout seul sa base (fichier dans `data/`, protégé).

## 2. Configurer le paiement Stripe
1. Créer le compte sur stripe.com (SIRET et IBAN de la micro-entreprise).
2. Copier la clé secrète (`sk_test_...` pour tester, `sk_live_...` en vrai) dans `config.php`, ligne `stripe_secret`.
3. Stripe > Développeurs > Webhooks > ajouter `https://votre-site/webhook.php`, événement `checkout.session.completed`. Copier la clé `whsec_...` dans `stripe_webhook_secret`.
4. Faire une commande test avec la carte `4242 4242 4242 4242` (date future, CVC au choix), puis passer en clés « live ».

## 3. Premiers réglages (admin > Réglages)
Nom, e-mail, lien Instagram, SIRET, adresse, frais de livraison, texte « Mon histoire » + photo, médiateur de la consommation (obligatoire dans les CGV).

## 4. Utilisation au quotidien
- **Produits** : ajouter, photos multiples, stock, tailles/couleurs/tissus (séparés par des virgules), masquer ou supprimer.
- **Commandes** : passer en « expédiée » envoie automatiquement un e-mail avec le suivi.
- **Remboursements** : depuis le tableau de bord Stripe.
- **Avis** : publiés après validation. **Sur mesure** : les demandes arrivent par e-mail et dans l'admin.

## 5. Logo
Déposer le logo dans `assets/` sous le nom `logo.png` (ou `logo.svg`) : il remplace automatiquement le logo provisoire.

## Sauvegarde
Copier régulièrement les dossiers `data/` et `uploads/` (commandes, produits, photos).
