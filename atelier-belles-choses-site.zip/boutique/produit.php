<?php
require __DIR__ . '/inc/layout.php';
$id = (int)($_GET['id'] ?? 0);
$p = row('SELECT * FROM products WHERE id = ? AND active = 1', [$id]);
if (!$p) {
    http_response_code(404);
    site_head('Introuvable');
    echo '<h1>Création introuvable</h1><p><a class="btn" href="' . url('boutique.php') . '">Retour à la boutique</a></p>';
    site_foot();
    exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    review_submit($id);
    redirect(url('produit.php?id=' . $id . '#avis'));
}
$imgs = product_images($id);
$sizes = opts($p['sizes']);
$colors = opts($p['colors']);
$fabrics = opts($p['fabrics']);
$ok = in_stock($p);
$reviews = rows("SELECT * FROM reviews WHERE product_id = ? AND status = 'validé' ORDER BY id DESC", [$id]);
site_head($p['name'], mb_substr(preg_replace('/\s+/', ' ', $p['description']), 0, 150));
?>
<div class="product">
  <div>
    <?php if ($imgs): ?>
      <img id="main-photo" src="<?= url('uploads/' . $imgs[0]['file']) ?>" alt="<?= e($p['name']) ?>">
      <?php if (count($imgs) > 1): ?><div class="thumbs"><?php foreach ($imgs as $im): ?><img src="<?= url('uploads/' . $im['file']) ?>" data-thumb="<?= url('uploads/' . $im['file']) ?>" alt=""><?php endforeach; ?></div><?php endif; ?>
    <?php else: ?><div id="main-photo" class="noimg" style="display:flex">Photo à venir</div><?php endif; ?>
  </div>
  <div>
    <p class="small"><a href="<?= url('boutique.php?cat=' . urlencode($p['category'])) ?>"><?= e($p['category']) ?></a></p>
    <h1><?= e($p['name']) ?></h1>
    <p class="price"><?= money((int)$p['price_cents']) ?></p>
    <p class="desc"><?= e($p['description']) ?></p>

    <?php if ($ok): ?>
    <form method="post" action="<?= url('panier.php') ?>">
      <?= csrf_field() ?><input type="hidden" name="action" value="add"><input type="hidden" name="pid" value="<?= $id ?>">
      <?php foreach (['size' => ['Taille / format', $sizes], 'color' => ['Couleur', $colors], 'fabric' => ['Tissu', $fabrics]] as $name => [$lbl, $vals]): if (!$vals) continue; ?>
        <label for="<?= $name ?>"><?= $lbl ?></label>
        <select id="<?= $name ?>" name="<?= $name ?>" required><?php foreach ($vals as $v): ?><option><?= e($v) ?></option><?php endforeach; ?></select>
      <?php endforeach; ?>
      <label for="qty">Quantité</label>
      <input id="qty" type="number" name="qty" value="1" min="1" <?= $p['made_to_order'] ? '' : 'max="' . (int)$p['stock'] . '"' ?> style="max-width:100px">
      <p class="hint"><?= $p['made_to_order'] ? 'Réalisé sur commande. ' . e(setting('delay_text')) : ((int)$p['stock'] <= 3 ? 'Plus que ' . (int)$p['stock'] . ' en stock' : 'En stock') ?></p>
      <p><button class="btn block" type="submit">Ajouter au panier</button></p>
    </form>
    <?php else: ?>
      <p><span class="tag bad">Épuisé</span></p>
      <p><a class="btn ghost" href="<?= url('sur-mesure.php') ?>">Demander une création similaire</a></p>
    <?php endif; ?>
    <p class="small"><?= e(setting('delay_text')) ?> Une adaptation ? <a href="<?= url('sur-mesure.php') ?>">Parlons-en</a>.</p>
  </div>
</div>

<h2 id="avis">Avis sur cette création</h2>
<?php foreach ($reviews as $r): ?>
  <div class="review"><?= stars((int)$r['rating']) ?> <strong><?= e($r['author']) ?></strong><p><?= nl2br(e($r['text'])) ?></p></div>
<?php endforeach; if (!$reviews) echo '<p class="muted">Pas encore d\'avis.</p>'; ?>
<details class="panel"><summary><strong>Laisser un avis</strong></summary>
  <form method="post"><?= csrf_field() ?>
    <div class="hp"><input type="text" name="website" tabindex="-1" autocomplete="off"></div>
    <label>Votre prénom</label><input type="text" name="author" required maxlength="60">
    <label>Note</label><select name="rating"><option value="5">★★★★★</option><option value="4">★★★★</option><option value="3">★★★</option><option value="2">★★</option><option value="1">★</option></select>
    <label>Votre avis</label><textarea name="text" required maxlength="1500"></textarea>
    <p><button class="btn" type="submit">Envoyer</button></p>
  </form>
</details>
<?php site_foot();
