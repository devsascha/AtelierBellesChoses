<?php
require __DIR__ . '/inc/layout.php';
$ref = (string)($_GET['ref'] ?? '');
$sid = (string)($_GET['session_id'] ?? '');
$o = row('SELECT * FROM orders WHERE ref = ?', [$ref]);
$paid = false;
if ($o && $sid !== '' && hash_equals((string)$o['stripe_session'], $sid)) {
    try {
        $s = stripe_call('GET', 'checkout/sessions/' . rawurlencode($sid));
        if (($s['payment_status'] ?? '') === 'paid') {
            finalize_order((int)$o['id']);
            $paid = true;
            unset($_SESSION['cart']);
        }
    } catch (Throwable $ex) {
        error_log('Stripe verif: ' . $ex->getMessage());
    }
}
site_head('Merci');
?>
<?php if ($paid): ?>
  <h1>Merci pour votre commande !</h1>
  <div class="panel">
    <p>Votre paiement est bien reçu. Commande <strong><?= e($ref) ?></strong>.</p>
    <p>Un e-mail de confirmation vous a été envoyé à <strong><?= e($o['email']) ?></strong> (pensez à vérifier vos courriers indésirables).</p>
    <p><?= e(setting('delay_text')) ?></p>
  </div>
  <p><a class="btn" href="<?= url('boutique.php') ?>">Retour à la boutique</a></p>
<?php else: ?>
  <h1>Commande en cours de vérification</h1>
  <p>Nous n'avons pas encore reçu la confirmation du paiement. Si vous avez bien payé, vous recevrez un e-mail sous peu. En cas de doute, contactez-nous à <a href="mailto:<?= e(setting('email_contact')) ?>"><?= e(setting('email_contact')) ?></a>.</p>
<?php endif; ?>
<?php site_foot();
