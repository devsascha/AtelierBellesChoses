<?php
declare(strict_types=1);

define('ROOT', dirname(__DIR__));
if (!is_file(ROOT . '/config.php')) {
    http_response_code(500);
    exit('Fichier config.php manquant : copiez config.sample.php en config.php.');
}
$CFG = require ROOT . '/config.php';

session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax', 'secure' => !empty($_SERVER['HTTPS'])]);
session_start();
date_default_timezone_set('Europe/Paris');

$dr = rtrim(str_replace('\\', '/', (string)realpath($_SERVER['DOCUMENT_ROOT'] ?? '')), '/');
$rt = str_replace('\\', '/', ROOT);
define('WEB', ($dr !== '' && str_starts_with($rt, $dr)) ? substr($rt, strlen($dr)) : '');

const ORDER_STATUSES = ['en attente de paiement', 'payée', 'en préparation', 'expédiée', 'terminée', 'annulée'];

/* ---------- Helpers ---------- */
function cfg(string $k, $d = '')
{
    global $CFG;
    return $CFG[$k] ?? $d;
}
function e($s): string
{
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}
function money(int $c): string
{
    return number_format($c / 100, 2, ',', ' ') . ' €';
}
function parse_price(string $s): int
{
    $s = str_replace([' ', '€', "\u{202f}", "\u{a0}"], '', $s);
    return (int)round(((float)str_replace(',', '.', $s)) * 100);
}
function url(string $p = ''): string
{
    return WEB . '/' . ltrim($p, '/');
}
function base_url(): string
{
    $u = (string)cfg('site_url');
    if ($u !== '') {
        return rtrim($u, '/') . WEB;
    }
    return (!empty($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . WEB;
}
function redirect(string $u): never
{
    header('Location: ' . $u);
    exit;
}
function opts(string $s): array
{
    return array_values(array_filter(array_map('trim', preg_split('/[,\n;]+/', $s) ?: []), fn($x) => $x !== ''));
}
function flash(string $msg, string $type = 'ok'): void
{
    $_SESSION['flash'][] = [$type, $msg];
}
function flash_show(): void
{
    foreach ($_SESSION['flash'] ?? [] as [$t, $m]) {
        echo '<div class="flash ' . e($t) . '">' . e($m) . '</div>';
    }
    unset($_SESSION['flash']);
}
function csrf_field(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(16));
    }
    return '<input type="hidden" name="csrf" value="' . e($_SESSION['csrf']) . '">';
}
function csrf_check(): void
{
    $tok = (string)($_SESSION['csrf'] ?? '');
    if ($tok === '' || !hash_equals($tok, (string)($_POST['csrf'] ?? ''))) {
        http_response_code(400);
        exit('Session expirée, merci de recharger la page.');
    }
}
function post(string $k, string $d = ''): string
{
    return trim((string)($_POST[$k] ?? $d));
}

/* ---------- Base de données (SQLite) ---------- */
function db(): PDO
{
    static $pdo = null;
    if ($pdo) {
        return $pdo;
    }
    $dir = ROOT . '/data';
    if (!is_dir($dir)) {
        mkdir($dir, 0750, true);
    }
    $pdo = new PDO('sqlite:' . $dir . '/shop.sqlite');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->exec("
    CREATE TABLE IF NOT EXISTS settings (k TEXT PRIMARY KEY, v TEXT);
    CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, category TEXT DEFAULT '', description TEXT DEFAULT '',
      price_cents INTEGER NOT NULL DEFAULT 0, stock INTEGER NOT NULL DEFAULT 1, made_to_order INTEGER NOT NULL DEFAULT 0,
      sizes TEXT DEFAULT '', colors TEXT DEFAULT '', fabrics TEXT DEFAULT '', active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS product_images (
      id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER NOT NULL, file TEXT NOT NULL, position INTEGER DEFAULT 0);
    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT, ref TEXT UNIQUE, created_at TEXT DEFAULT CURRENT_TIMESTAMP, paid_at TEXT,
      status TEXT NOT NULL DEFAULT 'en attente de paiement', name TEXT, email TEXT, phone TEXT, delivery TEXT,
      address TEXT, zip TEXT, city TEXT, shipping_cents INTEGER DEFAULT 0, total_cents INTEGER DEFAULT 0,
      note TEXT, stripe_session TEXT, tracking TEXT);
    CREATE TABLE IF NOT EXISTS order_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER NOT NULL, product_id INTEGER, name TEXT,
      size TEXT, color TEXT, fabric TEXT, qty INTEGER, unit_cents INTEGER);
    CREATE TABLE IF NOT EXISTS reviews (
      id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER, author TEXT, rating INTEGER, text TEXT,
      status TEXT DEFAULT 'en attente', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS requests (
      id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT DEFAULT CURRENT_TIMESTAMP, name TEXT, email TEXT, phone TEXT,
      type TEXT, details TEXT, measures TEXT, status TEXT DEFAULT 'nouvelle');
    ");
    $defaults = [
        'shop_name' => 'Atelier Belles Choses',
        'tagline' => 'Créations artisanales cousues main : pour elles, pour les bébés, pour offrir.',
        'email_contact' => (string)cfg('mail_notify', 'contact@exemple.fr'),
        'phone' => '', 'instagram_url' => '', 'owner_name' => '', 'siret' => '', 'address' => '',
        'categories' => 'Pulls,Pantalons,Chouchous,Vestes,Sacs',
        'shipping_label' => 'Livraison à domicile (Colissimo)', 'shipping_cents' => '690', 'free_from_cents' => '0',
        'pickup_enabled' => '1', 'pickup_text' => 'Retrait gratuit en main propre (rendez-vous convenu avec l\'atelier)',
        'delay_text' => 'Expédition sous 3 à 7 jours ouvrés selon la pièce.',
        'story_title' => 'Mon histoire',
        'story_text' => "Bienvenue dans mon atelier !\n\nIci, chaque pièce est pensée, coupée et cousue à la main, avec des tissus choisis un à un.\n\n(Texte à remplacer depuis l'espace admin > Réglages.)",
        'story_photo' => '',
        'mediator' => 'À compléter : nom et coordonnées du médiateur de la consommation',
    ];
    $ins = $pdo->prepare('INSERT OR IGNORE INTO settings (k, v) VALUES (?, ?)');
    foreach ($defaults as $k => $v) {
        $ins->execute([$k, $v]);
    }
    if (!$pdo->query("SELECT 1 FROM settings WHERE k = 'admin_hash'")->fetch()) {
        $ins->execute(['admin_hash', password_hash((string)cfg('admin_password', 'ChangezMoi!2026'), PASSWORD_DEFAULT)]);
    }
    return $pdo;
}
function rows(string $sql, array $p = []): array
{
    $s = db()->prepare($sql);
    $s->execute($p);
    return $s->fetchAll();
}
function row(string $sql, array $p = []): ?array
{
    $s = db()->prepare($sql);
    $s->execute($p);
    $r = $s->fetch();
    return $r ?: null;
}
function run(string $sql, array $p = []): void
{
    db()->prepare($sql)->execute($p);
}
function setting(string $k): string
{
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        foreach (rows('SELECT k, v FROM settings') as $r) {
            $cache[$r['k']] = (string)$r['v'];
        }
    }
    return $cache[$k] ?? '';
}
function set_setting(string $k, string $v): void
{
    run('INSERT INTO settings (k, v) VALUES (?, ?) ON CONFLICT(k) DO UPDATE SET v = excluded.v', [$k, $v]);
}

/* ---------- Produits & images ---------- */
function product_images(int $pid): array
{
    return rows('SELECT * FROM product_images WHERE product_id = ? ORDER BY position, id', [$pid]);
}
function cover(int $pid): ?string
{
    $r = row('SELECT file FROM product_images WHERE product_id = ? ORDER BY position, id LIMIT 1', [$pid]);
    return $r ? url('uploads/' . $r['file']) : null;
}
function in_stock(array $p): bool
{
    return (int)$p['made_to_order'] === 1 || (int)$p['stock'] > 0;
}
function save_image(string $tmp): ?string
{
    $info = @getimagesize($tmp);
    if (!$info) {
        return null;
    }
    $img = match ($info[2]) {
        IMAGETYPE_JPEG => @imagecreatefromjpeg($tmp),
        IMAGETYPE_PNG => @imagecreatefrompng($tmp),
        IMAGETYPE_WEBP => function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($tmp) : false,
        default => false,
    };
    if (!$img) {
        return null;
    }
    if ($info[2] === IMAGETYPE_JPEG && function_exists('exif_read_data')) {
        $ex = @exif_read_data($tmp);
        $o = $ex['Orientation'] ?? 1;
        $img = match ($o) { 3 => imagerotate($img, 180, 0), 6 => imagerotate($img, -90, 0), 8 => imagerotate($img, 90, 0), default => $img };
    }
    $w = imagesx($img);
    $h = imagesy($img);
    $max = 1400;
    if (max($w, $h) > $max) {
        $r = $max / max($w, $h);
        $img = imagescale($img, (int)round($w * $r), (int)round($h * $r));
    }
    $name = bin2hex(random_bytes(8)) . '.jpg';
    $dir = ROOT . '/uploads';
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    $bg = imagecreatetruecolor(imagesx($img), imagesy($img));
    imagefill($bg, 0, 0, imagecolorallocate($bg, 255, 255, 255));
    imagecopy($bg, $img, 0, 0, 0, 0, imagesx($img), imagesy($img));
    imagejpeg($bg, $dir . '/' . $name, 84);
    return $name;
}

/* ---------- Panier ---------- */
function cart_key(int $pid, string $s, string $c, string $f): string
{
    return $pid . '|' . $s . '|' . $c . '|' . $f;
}
function cart_lines(): array
{
    $lines = [];
    $total = 0;
    foreach ($_SESSION['cart'] ?? [] as $key => $it) {
        $p = row('SELECT * FROM products WHERE id = ? AND active = 1', [$it['pid']]);
        if (!$p) {
            unset($_SESSION['cart'][$key]);
            continue;
        }
        $qty = (int)$it['qty'];
        if (!$p['made_to_order']) {
            $qty = min($qty, max(0, (int)$p['stock']));
        }
        if ($qty < 1) {
            continue;
        }
        $line = $qty * (int)$p['price_cents'];
        $total += $line;
        $lines[] = ['key' => $key, 'p' => $p, 'qty' => $qty, 'size' => $it['size'], 'color' => $it['color'], 'fabric' => $it['fabric'],
            'unit' => (int)$p['price_cents'], 'total' => $line, 'img' => cover((int)$p['id'])];
    }
    return [$lines, $total];
}
function cart_count(): int
{
    $n = 0;
    foreach ($_SESSION['cart'] ?? [] as $it) {
        $n += (int)$it['qty'];
    }
    return $n;
}
function shipping_for(string $delivery, int $subtotal): int
{
    if ($delivery !== 'domicile') {
        return 0;
    }
    $free = (int)setting('free_from_cents');
    if ($free > 0 && $subtotal >= $free) {
        return 0;
    }
    return (int)setting('shipping_cents');
}

/* ---------- E-mails ---------- */
function send_mail(string $to, string $subject, string $body, string $replyTo = ''): void
{
    if ($to === '' || !filter_var($to, FILTER_VALIDATE_EMAIL)) {
        return;
    }
    $from = (string)cfg('mail_from', 'contact@exemple.fr');
    $h = "From: " . mb_encode_mimeheader(setting('shop_name')) . " <$from>\r\nContent-Type: text/plain; charset=UTF-8\r\n";
    if ($replyTo !== '' && filter_var($replyTo, FILTER_VALIDATE_EMAIL)) {
        $h .= "Reply-To: $replyTo\r\n";
    }
    @mail($to, mb_encode_mimeheader($subject), $body, $h);
}
function notify_owner(string $subject, string $body, string $replyTo = ''): void
{
    send_mail((string)cfg('mail_notify', setting('email_contact')), $subject, $body, $replyTo);
}

/* ---------- Commandes & Stripe ---------- */
function stripe_call(string $method, string $path, array $params = []): array
{
    $key = (string)cfg('stripe_secret');
    if ($key === '') {
        throw new RuntimeException('Clé Stripe manquante');
    }
    $ch = curl_init('https://api.stripe.com/v1/' . $path);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true, CURLOPT_USERPWD => $key . ':', CURLOPT_TIMEOUT => 30,
        CURLOPT_CUSTOMREQUEST => $method,
    ]);
    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
    }
    $out = curl_exec($ch);
    if ($out === false) {
        throw new RuntimeException('Stripe injoignable : ' . curl_error($ch));
    }
    $data = json_decode((string)$out, true) ?: [];
    if (isset($data['error'])) {
        throw new RuntimeException('Stripe : ' . ($data['error']['message'] ?? 'erreur'));
    }
    return $data;
}
function order_summary_text(array $o): string
{
    $t = "Commande {$o['ref']}\n";
    foreach (rows('SELECT * FROM order_items WHERE order_id = ?', [$o['id']]) as $i) {
        $opt = trim(implode(' / ', array_filter([$i['size'], $i['color'], $i['fabric']])));
        $t .= "- {$i['qty']} x {$i['name']}" . ($opt ? " ($opt)" : '') . ' : ' . money((int)$i['unit_cents'] * (int)$i['qty']) . "\n";
    }
    $t .= 'Livraison : ' . ($o['delivery'] === 'domicile' ? 'à domicile, ' . money((int)$o['shipping_cents']) : 'retrait en main propre') . "\n";
    $t .= 'Total : ' . money((int)$o['total_cents']) . "\n";
    return $t;
}
function finalize_order(int $id): void
{
    $pdo = db();
    $pdo->beginTransaction();
    $o = row('SELECT * FROM orders WHERE id = ?', [$id]);
    if (!$o || $o['status'] !== 'en attente de paiement') {
        $pdo->rollBack();
        return;
    }
    run("UPDATE orders SET status = 'payée', paid_at = datetime('now','localtime') WHERE id = ?", [$id]);
    foreach (rows('SELECT * FROM order_items WHERE order_id = ?', [$id]) as $i) {
        run('UPDATE products SET stock = MAX(0, stock - ?) WHERE id = ? AND made_to_order = 0', [$i['qty'], $i['product_id']]);
    }
    $pdo->commit();
    $txt = order_summary_text($o);
    $addr = $o['delivery'] === 'domicile' ? "\nAdresse : {$o['address']}, {$o['zip']} {$o['city']}" : '';
    send_mail($o['email'], 'Votre commande ' . $o['ref'] . ' - ' . setting('shop_name'),
        "Bonjour {$o['name']},\n\nMerci pour votre commande, le paiement est bien reçu.\n\n$txt$addr\n\n" . setting('delay_text') . "\nVous recevrez un e-mail à l'expédition.\n\nÀ bientôt,\n" . setting('shop_name'), setting('email_contact'));
    notify_owner('Nouvelle commande payée ' . $o['ref'], "$txt\nClient : {$o['name']} - {$o['email']} - {$o['phone']}$addr\nNote : {$o['note']}", $o['email']);
}

/* ---------- Avis ---------- */
function review_submit(?int $pid): bool
{
    if (post('website') !== '') {
        return true; // anti-spam (champ piège)
    }
    $author = mb_substr(post('author'), 0, 60);
    $text = mb_substr(post('text'), 0, 1500);
    $rating = max(1, min(5, (int)post('rating', '5')));
    if ($author === '' || $text === '') {
        flash('Merci d\'indiquer votre prénom et votre avis.', 'err');
        return false;
    }
    run('INSERT INTO reviews (product_id, author, rating, text) VALUES (?, ?, ?, ?)', [$pid, $author, $rating, $text]);
    notify_owner('Nouvel avis à valider', "$author ($rating/5) :\n$text\n\nÀ valider dans l'espace admin.");
    flash('Merci ! Votre avis sera publié après validation.');
    return true;
}
function stars(int $n): string
{
    return '<span class="stars" aria-label="' . $n . ' sur 5">' . str_repeat('★', $n) . str_repeat('☆', 5 - $n) . '</span>';
}

/* ---------- Admin ---------- */
function require_admin(): void
{
    if (empty($_SESSION['admin'])) {
        redirect(url('admin/login.php'));
    }
}
