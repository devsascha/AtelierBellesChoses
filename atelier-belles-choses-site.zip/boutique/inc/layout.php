<?php
require_once __DIR__ . '/bootstrap.php';

function logo_url(): string
{
    foreach (['logo.png', 'logo.jpg', 'logo.webp', 'logo.svg'] as $f) {
        if (is_file(ROOT . '/assets/' . $f)) {
            return url('assets/' . $f);
        }
    }
    return '';
}

function site_head(string $title, string $desc = ''): void
{
    $shop = setting('shop_name');
    $full = $title === '' ? $shop : $title . ' | ' . $shop;
    $desc = $desc ?: setting('tagline');
    $n = cart_count();
    ?><!doctype html>
<html lang="fr"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($full) ?></title>
<meta name="description" content="<?= e($desc) ?>">
<meta name="theme-color" content="#f6ece6">
<link rel="stylesheet" href="<?= url('assets/style.css') ?>">
</head><body>
<header class="site-header">
  <div class="wrap bar">
    <a class="brand" href="<?= url() ?>"><?php if (logo_url()): ?><img src="<?= e(logo_url()) ?>" alt="<?= e($shop) ?>"><?php else: ?><span><?= e($shop) ?></span><?php endif; ?></a>
    <input type="checkbox" id="nav-toggle" class="nav-toggle" aria-label="Menu">
    <label for="nav-toggle" class="burger" aria-hidden="true"><i></i></label>
    <nav class="nav">
      <a href="<?= url('boutique.php') ?>">Boutique</a>
      <a href="<?= url('sur-mesure.php') ?>">Sur mesure</a>
      <a href="<?= url('histoire.php') ?>">Mon histoire</a>
      <a href="<?= url('avis.php') ?>">Avis</a>
      <a class="cart-link" href="<?= url('panier.php') ?>">Panier<?php if ($n): ?> <b><?= $n ?></b><?php endif; ?></a>
    </nav>
  </div>
</header>
<main class="wrap">
<?php flash_show();
}

function site_foot(): void
{
    $insta = setting('instagram_url');
    ?></main>
<footer class="site-footer">
  <div class="wrap foot">
    <div>
      <strong><?= e(setting('shop_name')) ?></strong>
      <p><?= e(setting('tagline')) ?></p>
      <?php if ($insta): ?><p><a class="insta" href="<?= e($insta) ?>" target="_blank" rel="noopener">Suivez-nous sur Instagram</a></p><?php endif; ?>
    </div>
    <div>
      <strong>Informations</strong>
      <p><a href="<?= url('sur-mesure.php') ?>">Commande sur mesure</a><br>
      <a href="<?= url('cgv.php') ?>">Conditions générales de vente</a><br>
      <a href="<?= url('mentions-legales.php') ?>">Mentions légales</a><br>
      <a href="<?= url('confidentialite.php') ?>">Confidentialité</a></p>
    </div>
    <div>
      <strong>Contact</strong>
      <p><a href="mailto:<?= e(setting('email_contact')) ?>"><?= e(setting('email_contact')) ?></a><?php if (setting('phone')): ?><br><?= e(setting('phone')) ?><?php endif; ?></p>
      <p class="small">Paiement sécurisé par carte via Stripe.</p>
    </div>
  </div>
  <div class="copy">© <?= date('Y') ?> <?= e(setting('shop_name')) ?></div>
</footer>
<script>
document.querySelectorAll('[data-thumb]').forEach(function(t){t.addEventListener('click',function(){document.getElementById('main-photo').src=t.dataset.thumb;});});
</script>
</body></html>
<?php
}

function product_card(array $p): void
{
    $img = cover((int)$p['id']);
    $ok = in_stock($p);
    ?>
<a class="card" href="<?= url('produit.php?id=' . (int)$p['id']) ?>">
  <div class="ph"><?php if ($img): ?><img src="<?= e($img) ?>" alt="<?= e($p['name']) ?>" loading="lazy"><?php else: ?><span class="noimg">Photo à venir</span><?php endif; ?>
    <?php if (!$ok): ?><em class="badge out">Épuisé</em><?php elseif ($p['made_to_order']): ?><em class="badge">Sur commande</em><?php endif; ?></div>
  <h3><?= e($p['name']) ?></h3>
  <p class="price"><?= money((int)$p['price_cents']) ?></p>
</a>
<?php
}
