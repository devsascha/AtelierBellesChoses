<?php
require __DIR__ . '/inc/layout.php';
$new = rows('SELECT * FROM products WHERE active = 1 ORDER BY id DESC LIMIT 8');
$reviews = rows("SELECT * FROM reviews WHERE status = 'validé' ORDER BY id DESC LIMIT 3");
$cats = opts(setting('categories'));
site_head('', setting('tagline'));
?>
<section class="hero">
  <h1><?= e(setting('shop_name')) ?></h1>
  <p><?= e(setting('tagline')) ?></p>
  <a class="btn" href="<?= url('boutique.php') ?>">Découvrir la boutique</a>
  <a class="btn ghost" href="<?= url('sur-mesure.php') ?>">Une envie sur mesure ?</a>
</section>

<div class="cats">
  <?php foreach ($cats as $c): ?><a class="chip" href="<?= url('boutique.php?cat=' . urlencode($c)) ?>"><?= e($c) ?></a><?php endforeach; ?>
</div>

<h2>Les dernières créations</h2>
<?php if ($new): ?>
  <div class="grid"><?php foreach ($new as $p) { product_card($p); } ?></div>
<?php else: ?>
  <p class="muted">Les premières créations arrivent très bientôt.</p>
<?php endif; ?>

<div class="values">
  <div><strong>Fait main</strong>Chaque pièce est cousue dans l'atelier, avec soin.</div>
  <div><strong>Sur mesure</strong>Taille, couleur, tissu : on adapte la création à vous.</div>
  <div><strong>Pensé pour offrir</strong>Femmes, bébés, cadeaux : de jolies idées à glisser sous le sapin.</div>
</div>

<?php if ($reviews): ?>
<h2>Elles en parlent</h2>
<?php foreach ($reviews as $r): ?>
  <div class="review"><?= stars((int)$r['rating']) ?> <strong><?= e($r['author']) ?></strong><p><?= nl2br(e($r['text'])) ?></p></div>
<?php endforeach; ?>
<p><a href="<?= url('avis.php') ?>">Voir tous les avis</a></p>
<?php endif; ?>
<?php site_foot();
