<?php
// Point d'entrée appelé par Stripe (événement checkout.session.completed)
require __DIR__ . '/inc/bootstrap.php';

$payload = (string)file_get_contents('php://input');
$sig = (string)($_SERVER['HTTP_STRIPE_SIGNATURE'] ?? '');
$secret = (string)cfg('stripe_webhook_secret');
if ($secret === '') {
    http_response_code(503);
    exit('webhook non configuré');
}
$t = '';
$v1 = [];
foreach (explode(',', $sig) as $part) {
    [$k, $val] = array_pad(explode('=', trim($part), 2), 2, '');
    if ($k === 't') $t = $val;
    if ($k === 'v1') $v1[] = $val;
}
$expected = hash_hmac('sha256', $t . '.' . $payload, $secret);
$valid = false;
foreach ($v1 as $s) {
    if (hash_equals($expected, $s)) $valid = true;
}
if (!$valid || abs(time() - (int)$t) > 600) {
    http_response_code(400);
    exit('signature invalide');
}
$event = json_decode($payload, true) ?: [];
if (($event['type'] ?? '') === 'checkout.session.completed') {
    $obj = $event['data']['object'] ?? [];
    $oid = (int)($obj['metadata']['order_id'] ?? 0);
    if ($oid > 0 && ($obj['payment_status'] ?? '') === 'paid') {
        finalize_order($oid);
    }
}
http_response_code(200);
echo 'ok';
